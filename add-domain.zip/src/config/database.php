<?php
return [
    'host' => 'localhost',
    'dbname' => 'ced_rims',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4'
];